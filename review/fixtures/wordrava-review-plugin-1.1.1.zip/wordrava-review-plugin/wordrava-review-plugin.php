<?php
/**
 * Plugin Name: WordRava Review Plugin
 * Description: Inert fixture for testing WordRava ZIP inspection and inactive installation on a disposable review site.
 * Version: 1.1.1
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author: ShayanOstovar
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
// Intentionally no hooks, network calls, data writes or activation behavior.
