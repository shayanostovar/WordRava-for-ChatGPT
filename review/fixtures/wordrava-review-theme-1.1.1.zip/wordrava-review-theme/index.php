<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<h1><?php echo esc_html(get_bloginfo('name')); ?></h1>
<p>WordRava review fixture. Use only on a disposable review site.</p>
<?php wp_footer(); ?></body></html>
